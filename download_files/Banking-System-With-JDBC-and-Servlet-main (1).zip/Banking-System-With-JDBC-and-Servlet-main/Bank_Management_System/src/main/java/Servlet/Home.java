package Servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("transaction")
public class Home extends HttpServlet{
	protected void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException {
		String action=req.getParameter("action");
		
		if("Create_Account".equals(action)) {
			res.sendRedirect("create.jsp");
		}
		else if("Deposit".equals(action)) {
			res.sendRedirect("deposit.jsp");
		}
		else if("Withdraw".equals(action)) {
			res.sendRedirect("withdraw.jsp");
		}
		else if("Transfer_Amount".equals(action)){
			res.sendRedirect("transfer.jsp");
		}
		else if("Statement".equals(action)) {
			res.sendRedirect("deposit.jsp");
		}
		else {
            res.getWriter().println("Invalid action");
        }
		
	}
}
