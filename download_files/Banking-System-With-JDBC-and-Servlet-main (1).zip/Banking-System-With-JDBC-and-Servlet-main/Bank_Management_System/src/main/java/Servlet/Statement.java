package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DB.Account_Service;
import java.util.*;

@WebServlet("/statement")
public class Statement extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        String accNum = request.getParameter("account_number");
        String pin = request.getParameter("pin");

        Account_Service service = new Account_Service();
        ResultSet rs = service.Statement(accNum, pin);
        
        PrintWriter out = response.getWriter();

        out.println("<html><head><title>Account Statement</title></head><body>");
        out.println("<h2 style='text-align:center;'>Account Statement</h2>");

        if (rs == null) {
            out.println("<p style='color:red; text-align:center;'>No transactions found.</p>");
        } else {
            try {
                out.println("<table border='1' cellspacing='0' cellpadding='8' style='margin:auto;'>");
                out.println("<tr style='background-color:#f2f2f2;'>");
                out.println("<th>S.No</th>");
                out.println("<th>Date</th>");
                out.println("<th>Type</th>");
                out.println("<th>Amount</th>");
                out.println("<th>Balance</th>");
                out.println("</tr>");

                boolean hasData = false;
                while (rs.next()) {
                    hasData = true;
                    out.println("<tr>");
                    out.println("<td>" + rs.getInt("serialno") + "</td>");
                    out.println("<td>" + rs.getDate("transaction_date") + "</td>");
                    out.println("<td>" + rs.getString("transaction_type") + "</td>");
                    out.println("<td>" + rs.getDouble("amount") + "</td>");
                    out.println("<td>" + rs.getDouble("balance") + "</td>");
                    out.println("</tr>");
                }

                out.println("</table>");

                if (!hasData) {
                    out.println("<p style='color:red; text-align:center;'>No records found for this account.</p>");
                }

            } catch (Exception e) {
                out.println("<p style='color:red;'>Error fetching statement: " + e.getMessage() + "</p>");
            }
        }

        out.println("</body></html>");
        out.close();

    }
}
