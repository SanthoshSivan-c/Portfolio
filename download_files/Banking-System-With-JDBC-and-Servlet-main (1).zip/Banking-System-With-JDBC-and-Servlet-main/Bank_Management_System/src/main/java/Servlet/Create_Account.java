package Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import DB.Account;
import DB.Account_Service;

@WebServlet("/register")
public class Create_Account extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException{
		String account_number=req.getParameter("acc_num");
		String account_holder_name=req.getParameter("acc_hol_name");
		double amount=Double.parseDouble(req.getParameter("acc_bal"));
		String pin=req.getParameter("pin");
		
		Account acc=new Account();
		Account_Service service=new Account_Service();
		
        acc.setAccountNUmber(account_number);
        acc.setAccountHolderName(account_holder_name);
        acc.setAccountBalance(amount);
        acc.setPinNumber(pin);
		
		int rs=service.addAccount(acc);
		if(rs!=0) {
			req.getRequestDispatcher("withdraw.jsp").forward(req, res);;
		}else {
			req.getRequestDispatcher("insert.jsp").include(req, res);
			PrintWriter p=res.getWriter();
			p.print("<h1>Account is Not Created</h1>");
		}
		
	}

}
