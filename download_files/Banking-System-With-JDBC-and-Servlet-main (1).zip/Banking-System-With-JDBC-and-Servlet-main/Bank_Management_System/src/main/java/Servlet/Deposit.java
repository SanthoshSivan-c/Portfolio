package Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import DB.Account_Service;
@WebServlet("/deposit")
public class Deposit extends HttpServlet{
	protected void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException {
		String acc_num=req.getParameter("acc_num");
		String pin=req.getParameter("pin");
		double amt=Double.parseDouble(req.getParameter("amt"));
		
		Account_Service service=new Account_Service();
		
		int rs=service.deposit(acc_num, pin, amt);
		PrintWriter p=res.getWriter();
		if(rs!=0) {
			p.print("<h1>Rs."+amt+" Deposit Success</h1>");
		}else {
			req.getRequestDispatcher("deposit.jsp").include(req, res);
			p.print("<h1>Deposit Unsuccess</h1>");
		}

	}
}
