package Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DB.Account_Service;

@WebServlet("/transfer")
public class Transfer extends HttpServlet{
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException {
		String fromAcc=req.getParameter("from_acc");
		String toAcc=req.getParameter("to_acc");
		String pin=req.getParameter("pin");
		double amt=Double.parseDouble(req.getParameter("amt"));
		
		Account_Service service=new Account_Service();
		int rs=service.transfer(fromAcc, toAcc, pin, amt);
		PrintWriter p=res.getWriter();
		if(rs!=0) {
			p.print("<h1>Rs."+amt+" Has Been Transfered From "+fromAcc+" to "+toAcc+" Sucessfully</h1>");
		}else {
			req.getRequestDispatcher("transfer.jsp").include(req, res);
			p.print("<h1>Transfer Unsuccessfull</h1>");
		}
		
	}
}
