	package DB;
	import java.sql.*;
	public class Account_Service {
		private static String url="jdbc:postgresql://localhost:5432/bank?user=postgres&password=123";
		private static Connection conn;
		static {
			try {
				Class.forName("org.postgresql.Driver");
				conn=DriverManager.getConnection(url);
			}catch(SQLException e) {
				e.printStackTrace();
			}catch(ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		
		public int addAccount(Account acc) {
			int rs=0;
			String sql="insert into accountinfo values(?,?,?,?)";
			try {
				PreparedStatement pstm=conn.prepareStatement(sql);
				pstm.setString(1, acc.getAccountNUmber());
				pstm.setString(2, acc.getAccountHolderName());
				pstm.setString(3, acc.getPinNumber());
				pstm.setDouble(4, acc.getAccountBalance());
				rs=pstm.executeUpdate();
			}catch(SQLException e) {
				e.printStackTrace();
			}
			return rs;
		}
		
		public int deposit(String acc_num,String pin,double amt) {
			int rs=0;
			String sql="update accountinfo set accountbalance= accountbalance + ? WHERE accountnumber= ? and pinnumber= ?";
			try {
				PreparedStatement pstm=conn.prepareStatement(sql);
				pstm.setDouble(1, amt);
				pstm.setString(2, acc_num);
				pstm.setString(3, pin);
				rs=pstm.executeUpdate();
			}catch(SQLException e) {
				e.printStackTrace();
			}
			if(rs>0) {
				transactionInfo(acc_num, "deposit", amt);
			}
			return rs;
		}
		
		public int withdraw(String acc_num,String pin,double amt) {
			int res=0;
			String sql="select accountbalance from accountinfo where  accountnumber= ? and pinnumber= ?";
			try {
				PreparedStatement pstm=conn.prepareStatement(sql);
				pstm.setString(1, acc_num);
				pstm.setString(2, pin);
				ResultSet rs=pstm.executeQuery();
				if(rs.next()) {
					double bal=rs.getDouble("accountbalance");
					if(bal>= amt) {
						String sql1="update accountinfo set accountbalance= accountbalance - ? where accountnumber= ? and pinnumber= ?";
						try {
							PreparedStatement pstm1=conn.prepareStatement(sql1);
							pstm1.setDouble(1, amt);
							pstm1.setString(2, acc_num);
							pstm1.setString(3, pin);
							res=pstm1.executeUpdate();
						}catch(SQLException e) {
							e.printStackTrace();
						}
					}else {
						System.out.println("Insufficient Balance");
					}
				}else {
					System.out.println("Account Not Found");
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}
			if(res>0) {
				transactionInfo(acc_num, "withdraw", amt);
			}
			return res;
		}
		
		public int transfer(String fromacc, String toacc, String pin, double amt) {
		    int rs = 0;
		    String sqlCheck = "select accountbalance from accountinfo where accountnumber= ? and pinnumber= ?";
		    try {
		        conn.setAutoCommit(false);
		        PreparedStatement pstm = conn.prepareStatement(sqlCheck);
		        pstm.setString(1, fromacc);
		        pstm.setString(2, pin);
		        ResultSet res = pstm.executeQuery();
		        if (res.next()) {
		            double bal = res.getDouble("accountbalance");
		            if (bal >= amt) {
		                String sqlDebit = "update accountinfo set accountbalance=accountbalance - ? where accountnumber=? and pinnumber= ?";
		                PreparedStatement pstm1 = conn.prepareStatement(sqlDebit);
		                pstm1.setDouble(1, amt);
		                pstm1.setString(2, fromacc);
		                pstm1.setString(3, pin);
		                int debitRst = pstm1.executeUpdate();
		                if (debitRst > 0) {
		                    String sqlCredit = "update accountinfo set accountbalance=accountbalance + ? WHERE accountnumber= ?";
		                    PreparedStatement pstm2 = conn.prepareStatement(sqlCredit);
		                    pstm2.setDouble(1, amt);
		                    pstm2.setString(2, toacc);
		                    int creditRst = pstm2.executeUpdate();
		                    if (creditRst > 0) {
		                        conn.commit();
		                        rs = 1;
		                    } else {
		                        conn.rollback();
		                        System.out.println("Receiver account not found");
		                    }
		                } else {
		                    conn.rollback();
		                    System.out.println("Debit failed");
		                }
		            } else {
		                System.out.println("Insufficient Balance");
		            }
		        } else {
		            System.out.println("Sender Account Not Found");
		        }
	
		    } catch (SQLException e) {
		        try {
		            conn.rollback(); 
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		        e.printStackTrace();
		    } finally {
		        try {
		            conn.setAutoCommit(true);
		        } catch (SQLException e) {
		            e.printStackTrace();
		        }
		    }
		    if(rs>0) {
		        transactionInfo(fromacc, "transfer-debit", amt);
		        transactionInfo(toacc, "transfer-credit", amt);
		    }
	
		    return rs;
		}
		
		public int transactionInfo(String acc_num,String type,double amt) {
			int rs=0;
			String sqlbal="select accountbalance from accountinfo where accountnumber= ?";
			String sql = "insert into statement(accountnumber, transaction_date, transaction_type, amount, balance) values(?, current_date, ?, ?, ?)";
			try {
				PreparedStatement pstm=conn.prepareStatement(sqlbal);
				pstm.setString(1, acc_num);
				ResultSet rst=pstm.executeQuery();
				if(rst.next()) {
					double balance=rst.getDouble("accountbalance");
					
					PreparedStatement pstm1=conn.prepareStatement(sql);
					pstm1.setString(1, acc_num);
					pstm1.setString(2, type);
					pstm1.setDouble(3, amt);
					pstm1.setDouble(4, balance);
					rs=pstm1.executeUpdate();
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}
			return rs;
		}
	
		public ResultSet Statement(String acc_num,String pin) {
			ResultSet rs=null;
			String sql="select * from statement where accountnumber= ? and pin= ?";
			try {
				PreparedStatement pstm=conn.prepareStatement(sql);
				pstm.setString(1, acc_num);
				pstm.setString(2, pin);
				rs=pstm.executeQuery();
			}catch(SQLException e) {
				e.printStackTrace();
			}
			return rs;
		}
	
	}
