package DB;

public class Account {
	private String AccountNUmber;
	private String AccountHolderName;
	private double AccountBalance;
	private String PinNumber;
	
	public String getAccountNUmber() {
		return AccountNUmber;
	}
	public void setAccountNUmber(String accountNUmber) {
		AccountNUmber = accountNUmber;
	}
	public String getAccountHolderName() {
		return AccountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		AccountHolderName = accountHolderName;
	}
	public double getAccountBalance() {
		return AccountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		AccountBalance = accountBalance;
	}
	public void setPinNumber(String pin) {
		PinNumber = pin;
	}
	public String getPinNumber() {
		return PinNumber;
	}

}
