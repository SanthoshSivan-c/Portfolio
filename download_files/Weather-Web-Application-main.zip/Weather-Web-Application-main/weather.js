function getweather(){
    const api_key=`40a7cd4bf37e08e4abab6f7c84004fc8`;
    const city=document.getElementById('city').value;
    if(!city){
        alert("enter the city name");
        return;
    }
    const currweatherurl=`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${api_key}`;
    const forecasturl=`https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${api_key}`;
    fetch(currweatherurl).then(response=>response.json())
    .then(data=>{
        displayweather(data);
    })
    .catch(error=>{
        console.log(`Error in fetching the current weather data:`,error);
        alert(`Error fetching current weather data.Please try again`);
    })
    fetch(forecasturl).then(response=>response.json())
    .then(data=>{
        displayhourlyforecast(data.list);
    })
    .catch(error=>{
        console.log(`Error in fetching the hourly forecast data:`,error);
        alert(`Error fetching hourly forecast data.Please try again`);
    })   
}
function displayweather(data){
    const tempinfo=document.getElementById('temp-info')
    const weatherinfo=document.getElementById(`weather-info`);
    const weathericon=document.getElementById(`weather-icon`);
    const hourlyforecast=document.getElementById(`hourly-forecast`);
    
    tempinfo.innerHTML='';
    weatherinfo.innerHTML='';
    hourlyforecast.innerHTML='';

    if(data.cod==='404'){
        weatherinfo.innerHTML=`<P> ${data.message}</p>`;
    }
    else{
        const cityname=data.name;
        const temperature=Math.round(data.main.temp-273.15);
        const description=data.weather[0].description;
        const iconcode=data.weather[0].icon;
        const iconurl=`https://openweathermap.org/img/wn/${iconcode}@4x.png`;

        const temperatureHTML=`<p>${temperature}°C</p>`;

        const weatherHTML=`<p>${cityname}</p>
                            <p>${description}</p>`;

        tempinfo.innerHTML=temperatureHTML;
        weatherinfo.innerHTML=weatherHTML;
        weathericon.src=iconurl;
        weathericon.alt=description;

        showimage();
    }
}
function displayhourlyforecast(hourlydata){
    const hourlyforecastinfo=document.getElementById('hourly-forecast');
    hourlyforecastinfo.innerHTML = '';
    const next24hours=hourlydata.slice(0,8);
    next24hours.forEach(element => {
        const datetime=new Date(element.dt*1000);
        const hour=datetime.getHours();
        const temperature=Math.round(element.main.temp-273.15);
        const iconcode=element.weather[0].icon;
        const iconurl=`https://openweathermap.org/img/wn/${iconcode}.png`
    
        const hourlyelementHTML=`
         <div class="hourly-element">
            <span>${hour}:00</span>
            <img src="${iconurl}" alt="weather icon">
            <span>${temperature}°C</span>
        </div>
        `;
        hourlyforecastinfo.innerHTML+=hourlyelementHTML;

        
       
    });
}
function showimage(){
    const weathericon=document.getElementById('weather-icon');
    weathericon.style.display='block';
}
