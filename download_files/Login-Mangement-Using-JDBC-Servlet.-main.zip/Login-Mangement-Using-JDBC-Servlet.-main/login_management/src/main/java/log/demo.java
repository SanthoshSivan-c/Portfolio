package log;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import login_driver.login;
import login_driver.login_service;



@WebServlet("/register")
public class demo extends HttpServlet{
	protected void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException {
		String mail=req.getParameter("mail");
		String pass=req.getParameter("pass");
		
		login log=new login();
		log.setMail(mail);
		log.setPass(pass);
		
		login_service service=new login_service();
		int rs=service.insert(log);
		
		PrintWriter p=res.getWriter();
		if(rs>0) {
			//req.getRequestDispatcher("login.jsp").forward(req, res);
			res.sendRedirect("login.jsp");
		}else {
			p.print("<h1>Registeration Unseccesfull</h1>");
		}
	}

}
