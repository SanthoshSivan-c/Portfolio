package log;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import login_driver.login;
import login_driver.login_service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;



@WebServlet("/login")
public class loginuser extends HttpServlet {
	protected void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException{
		String mail=req.getParameter("mail");
		String pass=req.getParameter("pass");
		
		
		String action=req.getParameter("register");//name
		if("Register user".equals(action)) {//value
			res.sendRedirect("index.jsp");
			return;
		}
		
		login log=new login();
		log.setMail(mail);
		log.setPass(pass);
		
		login_service service=new login_service();
		boolean flag=service.fetch(log);
		PrintWriter p=res.getWriter();
		if(flag) {
			//req.getRequestDispatcher("home.jsp").forward(req, res);
			res.sendRedirect("home.jsp");
		}
		else {
			//p.print("<h1>invalid username</h1>");
			//req.getRequestDispatcher("login.jsp").include(req,res);
			res.sendRedirect("login.jsp");
		
		
		}
		
		
		
	}

}
