package login_driver;
import java.sql.*;

public class login_service {
	private static String url="jdbc:postgresql://localhost:5432/employee?user=postgres&password=123";
	private static Connection conn;
	static {
		try {
			Class.forName("org.postgresql.Driver");
			conn=DriverManager.getConnection(url);
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public int insert(login log) {
		int rs=0;
		String sql="insert into login values(?,?)";
		try {
			PreparedStatement pstm=conn.prepareStatement(sql);
			pstm.setString(1, log.getMail());
			pstm.setString(2, log.getPass());
			rs=pstm.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}
	
	public boolean fetch(login log) {
		String sql="select * from login where email=? and password=?";
		try {
			PreparedStatement pstm=conn.prepareStatement(sql);
			pstm.setString(1,log.getMail());
			pstm.setString(2,log.getPass());
			ResultSet res=pstm.executeQuery();
			if(res.next()) {
				System.out.println("email:"+res.getString(1));
				System.out.println("password:"+res.getString(2));
				return true;
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return  false;
	}
}
